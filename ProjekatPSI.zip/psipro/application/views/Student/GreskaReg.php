<!-- Todorović Jovana 0014/2013 -->

<?php include 'header.php';
include 'menu.php'; ?>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <h1 class="text-center login-title">GREŠKA! <br>Niste dobro uneli podatke. Obratite pažnju na format korisničkog imena, format unosenja pola i potvrdu šifre.</h1>

<?php include 'footer.php'; ?>