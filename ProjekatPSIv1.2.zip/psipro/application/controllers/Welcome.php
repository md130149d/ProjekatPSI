<?php
// Danko Miladinovic 149/13
class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->view('index');
	}
    public function zabSifra()
    {
        session_start();
        $this->load->helper('url');

        $this->load->view("zabSifra");
    }


    public function RandomString()
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randstring = '';
        for ($i = 0; $i < 10; $i++) {
            $randstring = $randstring . $characters[rand(0, strlen($characters))];
        }
        return $randstring;
    }

    public  function posaljiMejl($mail, $subject, $message) {
        $this->load->library('email');

        $config['protocol']    = 'smtp';
        $config['smtp_host']    = 'ssl://smtp.gmail.com';
        $config['smtp_port']    = '465';
        $config['smtp_timeout'] = '7';
        $config['smtp_user']    = 'edemonstrator@gmail.com';
        $config['smtp_pass']    = 'psiprojekat';
        $config['charset']    = 'utf-8';
        $config['newline']    = "\r\n";
        $config['mailtype'] = 'text'; // or html
        $config['validation'] = TRUE; // bool whether to validate email or not

        $this->email->initialize($config);

        $this->email->from('edemonstrator@gmail.com', 'eDemonstrator');
        $this->email->to($mail);
        $this->email->subject($subject);
        $this->email->message($message);

        $this->email->send();
    }




    public function slanjeMejla()
    {

        session_start();
        $this->load->helper('url');
        $kIme = $_POST['Kime'];


        $mail = $kIme.'@etf.rs';
        $sifra = $this->RandomString();
        $this->load->database();
        $this->db->select('SifZ');
        $this->db->from('zaposleni');
        $this->db->where('SifZ', $kIme);
        $slike = $this->db->get()->result_array();

        if(empty($slike)) return $this->load->view("Greska");

        if(!isset($slike)) $this->load->view("Student/Greska");
        else{
            $this->load->database();
            $this->db->select('SifZ');
            $this->db->from('Zaposleni');
            $this->db->where('SifZ', $kIme);
            $data = array('Sifra'=>$sifra);
            $this->db->update('Zaposleni',$data);
            $subject='Promena šifre';
            $tekst = 'Vaša nova šifra je: '.$sifra;

            $this->posaljiMejl($mail,$subject,$tekst);
            $this->load->view("obavestenjeSifra");

        }

    }
	public function logInProfesor(){
        $this->load->driver('session');
        $this->load->helper('url');
        if(isset($_POST['SifZ'])) {
            $this->session->set_userdata('username', $_POST['SifZ']);
            $this->load->database();
            $username=$this->db->escape($_POST['SifZ']);
            //var_dump($username);
            $password=$this->db->escape($_POST['Sifra']);
            $q=$this->db->query("Select Ime, Prezime, Pol From Zaposleni WHERE SifZ=$username AND Sifra=$password")->row();
          //  var_dump($q);
           // exit();
            if (empty($q)) {
                $q=$this->db->query("Select SifA From Admin Where SifA=$username AND Sifra=$password")->row();
                if(!empty($q)){
                    $this->session->set_userdata('username', $_POST['SifZ']);
                    //$this->session->set_userdata('userdata');
                    redirect("Admin/index");
                }
                else {
                    $data['message'] = "Pogrešna šifra ili korisničko ime!";
                   // $this->load->view("logInProfesor", $data);
                    redirect('Welcome/logInProfesor?message='.$data['message']);
                }
            } else {
                $this->session->set_userdata('username', $_POST['SifZ']);
                $this->session->set_userdata('imePrezime', "" . ($q->Ime) . " " . ($q->Prezime) . "");
                $this->session->set_userdata('pol', $q->Pol);
                $data['imePrezime'] = "" . ($q->Ime) . " " . ($q->Prezime) . "";
                redirect("Profesor/pocetna", $data);
            }
        }
        else {
            if(isset($_GET['message'])){
                $data['message']=$_GET['message'];
                $this->load->view("logInProfesor",$data);
            }
            else $this->load->view("logInProfesor");
        }
	}
}
