<!-- Todorović Jovana 0014/2013 -->

<?php include 'header.php';
include 'menu.php'; ?>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<h1 class="text-center login-title">GREŠKA! <br>Korisnik sa datim korisničkim imenom ne postoji u bazi. Možete prodneti zahtev za registraciju.</h1>

<?php include 'footer.php'; ?>