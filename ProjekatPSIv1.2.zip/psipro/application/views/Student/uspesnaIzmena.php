<!-- Todorović Jovana 0014/2013 -->
<?php include 'headerS.php';
include 'menuS.php'; ?>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <h1 class="text-center login-title">Uspešno ste podneli zahtev za izmenu podataka. <br>Sačekajte da vam administrator odobri zahtev.</h1>

<?php include 'footer.php'; ?>