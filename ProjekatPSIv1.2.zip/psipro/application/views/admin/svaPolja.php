<?php
//Snezana Tanic 0237/13
//Marijana Prpa 0442/13
?>

<div id="content">
    <div class="top">
        <div class="left"></div>
        <div class="right"></div>
        <div class="middle"></div>
    </div>



    <h2>Potrebno je uneti sva polja!</h2>
    <div class="bottom">
        <div class="left"></div>
        <div class="right"></div>
        <div class="middle"></div>
    </div>
</div>
