<?php
    //Danko Miladinovic 149/13
    if(isset($message)) echo "<p>$message</p>";
?>