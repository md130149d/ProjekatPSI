<!-- Todorović Jovana 0014/2013 -->
<?php include 'headerS.php';
include 'menuS.php'; ?>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <h1 class="text-center login-title">USPEŠNO STE POSLALI PRIJAVU!</h1>

<?php include 'footer.php'; ?>